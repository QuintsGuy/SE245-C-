﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonV2_Lab
{
    public class PersonV2: Person
    {
        private string _cellPhone;
        private string _instagramURL;

        public string CellPhone
        {
            get { return _cellPhone; }
            set
            {
                if (Validations.NullorEmpty(value) == true)
                {
                    _cellPhone = value;
                }
                else if (Validations.IsADouble(value)==false)
                {
                    Feedback += "\nERROR: Cellphone must only contain numbers";
                }
                else if (Validations.ExactLength(value, 10)==false)
                {
                    Feedback += "\nERROR: Cellphone must contain 10 numbers";
                }
                else
                {
                    _cellPhone = value;
                }
            }
        }
        public string InstagramURL
        {
            get { return _instagramURL; }
            set
            {
                if (Validations.NullorEmpty(value) == true)
                {
                    _instagramURL = value;
                }
                else if (Validations.GotProfanity(value))
                {
                    Feedback += "\nYour Instagram URL cannot contain profanity";
                }
                else if (Validations.ValidInstagramURL(value)==false)
                {
                    Feedback += "\nInvalid URL to instagram";
                }
                else
                {
                    _instagramURL = value;
                }
            }
        }

        private string GetConnected()
        {
            return @"Server=sql.neit.edu,4500;Database=SE133_TKnott;User Id=SE133_TKnott;Password=008018683;";
        }
        
        public string addRecord()
        {
            string strResult = "";
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = GetConnected();
            
            string strSQL = "INSERT INTO PersonV2 (FName, MName, LName, Street1, Street2, City, State, Zipcode, Phone, CellPhone, Email, InstagramURL) " +
                            "VALUES (@FName, @MName, @LName, @Street1, @Street2, @City, @State, @Zipcode, @Phone, @CellPhone, @Email, @InstagramURL)";

            SqlCommand comm = new SqlCommand();
            comm.CommandText = strSQL;
            comm.Connection = conn;

            comm.Parameters.AddWithValue("@FName", FName);
            comm.Parameters.AddWithValue("@MName", MName);
            comm.Parameters.AddWithValue("@LName", LName);
            comm.Parameters.AddWithValue("@Street1", Street1);
            comm.Parameters.AddWithValue("@Street2", Street2);
            comm.Parameters.AddWithValue("@City", City);
            comm.Parameters.AddWithValue("@State", State);
            comm.Parameters.AddWithValue("@Zipcode", ZipCode);
            comm.Parameters.AddWithValue("@Phone", Phone);
            comm.Parameters.AddWithValue("@CellPhone", CellPhone);
            comm.Parameters.AddWithValue("@Email", Email);
            comm.Parameters.AddWithValue("@InstagramURL", InstagramURL);

            try
            {
                conn.Open();
                int intRecs = comm.ExecuteNonQuery();
                strResult = $"SUCCESS: Inserted {intRecs} records.";
                conn.Close();
            }
            catch (Exception err)
            {
                strResult = "ERROR: " + err.Message;
            }
            finally{}

            return strResult;
        }
    }
}