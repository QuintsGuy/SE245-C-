﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Payroll_Calculator
{
    class Program
    {
        public static void Main(string[] args)
        {
            List<string> names = new List<string>();
            List<double> hours = new List<double>();
            List<double> rates = new List<double>();
            List<double> grossPay = new List<double>();
            List<double> taxes = new List<double>();
            List<double> netPay = new List<double>();

            string runProgram;
            
            Console.WriteLine("Enter payroll information for the employee");

            do
            {
                Console.Write("\nPlease enter the employee's name: ");
                string employeeName = Console.ReadLine();
                names.Add(employeeName);
                
                double hoursWorked;
                while (true)
                {
                    Console.Write("Hour many hours did the employee work: ");
                    try
                    {
                        hoursWorked = double.Parse(Console.ReadLine());
                        break; 
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Invalid input. Please enter a valid number.");
                    }
                }
                hours.Add(hoursWorked);

                double hourlyRate;
                while (true)
                {
                    Console.Write("What is the employee's hourly rate: ");
                    try
                    {
                        hourlyRate = double.Parse(Console.ReadLine());
                        break; // break out of the loop if successful parse
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("Invalid input. Please enter a valid number.");
                    }
                }
                rates.Add(hourlyRate);

                double weeklyGrossPay = hoursWorked * hourlyRate;
                grossPay.Add(weeklyGrossPay);
                
                double taxRate = 0;
                if (weeklyGrossPay > 1000)
                {
                    taxRate = 0.3;
                }
                else if (weeklyGrossPay >= 750 && weeklyGrossPay < 1000)
                {
                    taxRate = 0.2;
                }
                else
                {
                    taxRate = 0.1;
                }

                double taxAmount = weeklyGrossPay * taxRate;
                taxes.Add(taxAmount);

                double totalPay = weeklyGrossPay - taxAmount;
                netPay.Add(totalPay);
                
                Console.WriteLine("\nPay Summary:");

                Console.WriteLine("{0,-15}{1,-10}{2,-10}{3,-10}{4,-10}{5,-10}",
                    "Name", "Hours", "Rate", "GrossPay", "Taxes", "NetPay");

                for (int i = 0; i < names.Count; i++)
                {
                    Console.WriteLine("{0,-15}{1,-10}{2,-10}{3,-10}{4,-10}{5,-10}",
                        names[i], hours[i], rates[i], grossPay[i], taxes[i], netPay[i]);
                }

                Console.Write("\nWould you like to calculate another employee's pay? (y/n): ");
                runProgram = Console.ReadLine().ToLower();
            } while (runProgram == "y");

            Console.ReadLine();
        }
    }
}