﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Payroll_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> names = new List<string>();
            List<double> hours = new List<double>();
            List<double> rates = new List<double>();
            List<double> taxes = new List<double>();

            Console.WriteLine("Enter payroll information for each employee");

            Console.Write("Please enter your name: ");
            string name = Console.ReadLine();

            names.Add(name);
       
            while (true)
            {
                Console.Write("\nHow many hours did you work: ");
                double hoursWorked = double.Parse(Console.ReadLine());
                hours.Add(hoursWorked);

                Console.Write("\nWhat is your hourly rate: ");
                double hourlyRate = double.Parse(Console.ReadLine());
                rates.Add(hourlyRate);

                double taxRate = 0;
                if (hourlyRate < 10.0)
                {
                    taxRate = 0.1;
                }
                else if (hourlyRate >= 10.0 && hourlyRate < 20.0)
                {
                    taxRate = 0.2;
                }
                else
                {
                    taxRate = 0.3;
                }

                double taxAmount = hoursWorked * hourlyRate * taxRate;
                taxes.Add(taxAmount);

                Console.WriteLine("\nPayroll Summary: \n");

                double totalPay = 0.0;

                for (int i =0; i < names.Count; i++)
                {
                    double pay = hours[i] * rates[i] - taxes[i];
                    totalPay += pay;

                    Console.WriteLine($"{names[i]}: {pay:C}");
                }

                double averageIncome = totalPay / names.Count;
                Console.WriteLine($"Average Income: {averageIncome:C}");

                Console.ReadLine();

            }
        }
    }
}
